uptime_now=" 01:10:03 up 46 days, 4:06, load average: 0.00, 0.01, 0.04";
temperatur="20130805 01:10 19.625";
wlan=" Link Quality=44/70 Signal level=-66 dBm ";
